export class Tag{
    tag :string = '';
    constructor (tag:string){
        this.tag = tag;
    }
}