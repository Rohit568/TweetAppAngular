export class ChangePassword{
    password : string = '';
    constructor (password:string){
        this.password = password;
    }
}