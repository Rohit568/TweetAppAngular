
export class ResponseMessage{
    message :string = '';
    constructor(message:string){
        this.message = message;
    }
}