export class IsAuthorized{
    auth:boolean = false;
    constructor(isAuthorized : boolean){
        this.auth= isAuthorized;
    }
}